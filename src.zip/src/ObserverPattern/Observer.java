package ObserverPattern;

import MelbourneWeather.ExceptionException;

import java.rmi.RemoteException;

public interface Observer {

    public void update(String location, Double temperature, Double rainfall, String time) throws RemoteException, ExceptionException;

}
