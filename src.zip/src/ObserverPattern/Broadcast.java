package ObserverPattern;


public class Broadcast {

    public String location;
    public double temperature;
    public double rainfall;
    public String time;


    public String getLocation() {

        return location;

    }

    public void setLocations(String location) {

        this.location = location;

    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }


    public double getRainfall() {
        return rainfall;
    }

    public void setRainfall(double rainfall) {
        this.rainfall = rainfall;
    }

    public String getTime() {

        return time;

    }

    public void setTime(String time) {

        this.time = time;

    }

}