package ObserverPattern;

import MelbourneWeather.ExceptionException;

import java.rmi.RemoteException;
import java.util.ArrayList;


public class WeatherData implements Subject {

    private ArrayList observers;
    private String location;
    private Double temperature;
    private Double rainfall;
    private String time;

    public WeatherData() {
        observers = new ArrayList();
    }

    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        int i = observers.indexOf(o);
        if (i >= 0) {
            observers.remove(i);
        }
    }
    @Override
    public void notifyObservers() throws RemoteException, ExceptionException {
        for (int i = 0; i < observers.size(); i++) {
            Observer observer = (Observer) observers.get(i);
            observer.update(location, temperature, rainfall, time);
        }
        }

    public void measurementsChanged() throws RemoteException, ExceptionException {
        notifyObservers();
    }


    public void setMeasurements(String location, Double temperature, Double rainfall, String time) throws
            RemoteException, ExceptionException {
        this.location = location;
        this.temperature = temperature;
        this.rainfall = rainfall;
        this.time = time;

        measurementsChanged();
    }
    }

