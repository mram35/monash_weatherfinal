package ObserverPattern;

import MelbourneWeather.ExceptionException;

import java.rmi.RemoteException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WeatherStation extends TimerTask {

    public static String chosenLocation;

    public static void main(String[] args) throws RemoteException, ExceptionException {

        Timer timer = new Timer();
        timer.schedule(new WeatherStation(), 0, 5 * 60000);
    }


    @Override
    public void run() {

        WeatherData weatherData = new WeatherData();
        Temperature temperature = new Temperature();
        Rainfall rainfall = new Rainfall();


        try {


            CurrentConditionsDisplay currentDisplay = new CurrentConditionsDisplay(weatherData);
            temperature.setTemperature(chosenLocation);
            rainfall.setRainfall(chosenLocation);


            weatherData.setMeasurements(chosenLocation, temperature.getTemperature(), rainfall.getRainfall(), temperature.getTime());

        } catch (Exception e) {
            e.printStackTrace();
            Logger.getLogger(CurrentConditionsDisplay.class.getName()).log(Level.SEVERE, null, e);
        }


    }


    public void init(String selectedItem) {
        chosenLocation = selectedItem;
    }

}
