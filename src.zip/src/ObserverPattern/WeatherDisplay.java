package ObserverPattern;

import MelbourneWeather.ExceptionException;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WeatherDisplay extends Application  {

    @FXML
    static Label txtLocation;
    @FXML
    private static Label temperature;
    @FXML
    private static Label rainfall;
    @FXML
    private ImageView weatherImage;
    @FXML
    private static Label time;


    private Double temp;
    private Double rain;
    private String tim;
    private String loc;

    public WeatherDisplay() {
    }

    public static void main(String[] args) throws RemoteException, ExceptionException {

        Application.launch(WeatherDisplay.class, (java.lang.String[]) null);
    }

    public static void display(String loca) {

        txtLocation.setText(loca);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        try {

            FXMLLoader loader = new FXMLLoader(WeatherDisplay.class.getResource("WeatherDisplay.fxml"));
            Pane page = loader.load();

            Scene scene = new Scene(page);
            Stage stage = new Stage();
            txtLocation.setText("Laverton");
            stage.setTitle("Weather Forecast");
            stage.setScene(scene);
            stage.show();


        } catch (Exception e) {

            Logger.getLogger(WeatherDisplay.class.getName()).log(Level.SEVERE, null, e);
        }
    }


}
