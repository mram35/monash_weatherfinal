package ObserverPattern;

import MelbourneWeather.ExceptionException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;



import java.awt.*;
import java.rmi.RemoteException;


public class CurrentConditionsDisplay implements Observer  {

    private Double temp;
    private Double rain;
    private String Tim;
    private String location;
    private Subject weatherData;


    public CurrentConditionsDisplay(Subject weatherData) throws RemoteException, ExceptionException{

        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }




    @Override
    public void update(String location, Double temperature, Double rainfall, String time) throws RemoteException, ExceptionException {
        this.location = location;
        this.temp = temperature;
        this.rain = rainfall;
        this.Tim = time;
        display();
    }

    public void display() throws RemoteException, ExceptionException {

        WeatherDisplay.display(location);
        Broadcast broadcast = new Broadcast();

        broadcast.setLocations(location);
        broadcast.setTemperature(temp);
        broadcast.setRainfall(rain);
        broadcast.setTime(Tim);
    }



}