package ObserverPattern;

public interface DisplayElement {
    public void display();
}