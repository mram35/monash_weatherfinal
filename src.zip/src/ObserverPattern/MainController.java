package ObserverPattern;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import MelbourneWeather.ExceptionException;

import java.awt.*;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainController  {


    @FXML private Button searchButton;
    @FXML private ChoiceBox<String> locationArr;


    public void initialize() throws RemoteException, ExceptionException {

        Location newLoc = new Location();
        locationArr.getItems().addAll(newLoc.getLocations());



        searchButton.setOnAction((ActionEvent event) -> {

            try {

                FXMLLoader loader = new FXMLLoader(getClass().getResource("WeatherDisplay.fxml"));

                Parent root = loader.load();

                Scene scene = new Scene(root);
                Stage stage = new Stage();

                stage.setTitle("Weather Forecast");
                stage.setScene(scene);
                stage.show();


                WeatherStation weatherStation = new WeatherStation();

                weatherStation.init(locationArr.getSelectionModel().getSelectedItem());

                WeatherStation.main(null);
               // WeatherDisplay.display();


            } catch (Exception e) {

                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
            }

        });

    }

}



